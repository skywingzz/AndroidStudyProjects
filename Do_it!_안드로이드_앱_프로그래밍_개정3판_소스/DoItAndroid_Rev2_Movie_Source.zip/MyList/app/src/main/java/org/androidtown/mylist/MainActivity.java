package org.androidtown.mylist;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView listView;

    String[] names = {"소녀시대", "티아라", "걸스데이", "EXID", "아이유"};
    String[] ages = {"20", "21", "22", "21", "24"};
    int[] resIds = {R.drawable.face01, R.drawable.face02, R.drawable.face03, R.drawable.face04, R.drawable.face05};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = (ListView) findViewById(R.id.listView);
        MyAdapter adapter = new MyAdapter();

        for (int i = 0; i < names.length; i++) {
            adapter.addItem(new SingerItem(names[i], ages[i], resIds[i]));
        }

        //String[] names = {"소녀시대", "티아라", "걸스데이", "EXID", "아이유"};
        //ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, names);

        listView.setAdapter(adapter);

    }


    public void onButton1Clicked(View v) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("테스트");
        builder.setMessage("테스트 대화상자입니다.");
        builder.setPositiveButton("예", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);

        dialog.show();
    }


    class MyAdapter extends BaseAdapter {
        ArrayList<SingerItem> items = new ArrayList<SingerItem>();

        public void addItem(SingerItem item) {
            items.add(item);
        }

        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            /*
            LinearLayout layout = new LinearLayout(getApplicationContext());
            layout.setOrientation(LinearLayout.VERTICAL);

            TextView view = new TextView(getApplicationContext());
            view.setText(names[position]);
            view.setTextSize(40.0f);
            view.setTextColor(Color.BLUE);
            layout.addView(view);

            TextView view2 = new TextView(getApplicationContext());
            view2.setText(ages[position]);
            view2.setTextSize(20.0f);
            view2.setTextColor(Color.RED);
            layout.addView(view2);
            */

            SingerView view = new SingerView(getApplicationContext());
            SingerItem item = items.get(position);

            view.setName(item.getName());
            view.setAge(item.getAge());
            view.setImage(item.getResId());

            return view;
        }
    }

}
