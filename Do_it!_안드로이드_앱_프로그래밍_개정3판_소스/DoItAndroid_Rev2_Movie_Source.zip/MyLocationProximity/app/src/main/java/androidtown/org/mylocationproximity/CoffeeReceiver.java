package androidtown.org.mylocationproximity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class CoffeeReceiver extends BroadcastReceiver {
    public CoffeeReceiver() {
    }

    @Override
    public void onReceive(Context context, Intent intent) {

        if (intent != null) {
            int id = intent.getIntExtra("id", 0);
            double latitude = intent.getDoubleExtra("latitude", 0.0D);
            double longitude = intent.getDoubleExtra("longitude", 0.0D);

            Toast.makeText(context, "������ Ŀ�Ǽ� : " + id + ", " + latitude + ", " + longitude, Toast.LENGTH_LONG).show();
        }

    }
}
