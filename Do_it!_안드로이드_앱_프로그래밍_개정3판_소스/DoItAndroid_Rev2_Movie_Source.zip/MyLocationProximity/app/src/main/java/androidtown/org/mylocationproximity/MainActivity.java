﻿package androidtown.org.mylocationproximity;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    TextView textView;
    TextView textView2;

    LocationManager manager;

    ArrayList<PendingIntent> pendingList = new ArrayList<PendingIntent>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView) findViewById(R.id.textView);
        textView2 = (TextView) findViewById(R.id.textView2);

        manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

    }

    public void onButton1Clicked(View v) {
        pendingList.clear();

        PendingIntent pIntent = register(1001, 36.222222, 126.222222, 200, -1);
        if (pIntent != null) {
            pendingList.add(pIntent);
        }

        pIntent = register(1002, 38.222222, 128.222222, 200, -1);
        if (pIntent != null) {
            pendingList.add(pIntent);
        }

        textView.setText("1001 : 36.222222, 126.222222");
        textView2.setText("1002 : 38.222222, 128.222222");

        Toast.makeText(this, "2개 지점 등록", Toast.LENGTH_LONG).show();
    }

    public void onButton2Clicked(View v) {
        unregister();

        Toast.makeText(this, "2개 지점 등록 해제됨", Toast.LENGTH_LONG).show();
    }

    private PendingIntent register(int id, double latitude, double longitude, float radius, long expiration) {
        Intent intent = new Intent("coffeeProximity");
        intent.putExtra("id", id);
        intent.putExtra("latitude", latitude);
        intent.putExtra("longitude", longitude);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, id, intent, PendingIntent.FLAG_CANCEL_CURRENT);
        manager.addProximityAlert(latitude, longitude, radius, expiration, pendingIntent);

        return pendingIntent;
    }

    private void unregister() {
        for (int i = 0; i < pendingList.size(); i++) {
            PendingIntent pIntent = pendingList.get(i);
            manager.removeProximityAlert(pIntent);
        }
    }

}
