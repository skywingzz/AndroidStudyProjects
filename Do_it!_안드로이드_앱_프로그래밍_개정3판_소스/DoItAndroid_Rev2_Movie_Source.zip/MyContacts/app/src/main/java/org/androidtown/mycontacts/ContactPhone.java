package org.androidtown.mycontacts;

/**
 * 전화번호 정보를 담기 위한 클래스 정의
 */
public class ContactPhone {
	public String number;
	public String type;

	public ContactPhone(String number, String type) {
		this.number = number;
		this.type = type;
	}
}
