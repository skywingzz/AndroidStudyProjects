package org.androidtown.mycontacts;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * 전화번호부 리스트를 위한 어댑터
 */
public class ContactsAdapter extends ArrayAdapter<Contact> {

	public ContactsAdapter(Context context, ArrayList<Contact> contacts) {
		super(context, 0, contacts);
	}

    /**
     * 새로운 데이터 리스트 설정
     * 기존 데이터는 삭제됨
     */
    public void setItems(ArrayList<Contact> contacts) {
        clear();
        addAll(contacts);
    }

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// 레이아웃 인플레이션
		View view = null;
		if (view == null) {
			LayoutInflater inflater = LayoutInflater.from(getContext());
			view = inflater.inflate(R.layout.contact_item, parent, false);
		} else {
            view = convertView;
        }

        // 데이터 설정
        Contact contact = getItem(position);

        TextView nameTextView = (TextView) view.findViewById(R.id.nameTextView);
		TextView emailTextView = (TextView) view.findViewById(R.id.emailTextView);
		TextView phoneTextView = (TextView) view.findViewById(R.id.phoneTextView);
        TextView ringtoneTextView = (TextView) view.findViewById(R.id.ringtoneTextView);

        nameTextView.setText(contact.name);
        emailTextView.setText("");
        phoneTextView.setText("");

        if (contact.emails.size() > 0 && contact.emails.get(0) != null) {
            emailTextView.setText(contact.emails.get(0).address);
		}

		if (contact.numbers.size() > 0 && contact.numbers.get(0) != null) {
            phoneTextView.setText(contact.numbers.get(0).number);
		}

        if (contact.ringtone == null) {
            ringtoneTextView.setText("");
        } else {
            ringtoneTextView.setText("(" + contact.ringtoneTitle + ") " + contact.ringtone);
        }

        return view;
	}

}
