﻿package org.androidtown.mycontacts;

import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


/**
 * 전화번호부 데이터를 리스트에 보여주는 예제
 *
 * 이름, 전화번호, 이메일, 벨소리를 화면에 보여줍니다.
 * 벨소리를 선택하여 저장하는 기능이 들어 있습니다.
 *
 */
public class MainActivity extends AppCompatActivity {
    ArrayList<Contact> contactList;

    ListView contactListView;
    ContactsAdapter contactAdapter;

    // 벨소리 선택 화면을 띄우기 위한 요청 코드 상수
    private static final int REQUEST_CODE_PICK_RINGTONE = 1001;

    Contact curContact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        contactList = new ContactFetcher(this).fetchAll();
        contactListView = (ListView) findViewById(R.id.contactListView);
        contactAdapter = new ContactsAdapter(this, contactList);
        contactListView.setAdapter(contactAdapter);

        contactListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // 선택된 Contact 객체 참조
                curContact = contactAdapter.getItem(position);
                Uri ringtoneUri = null;
                if (curContact.ringtone != null) {
                    ringtoneUri = Uri.parse(curContact.ringtone);
                }

                // 벨소리 선택을 위한 화면 띄우기
                showPickRingtoneActivity(ringtoneUri);

            }
        });

    }

    /**
     * 벨소리 선택을 위한 화면 띄우기
     */
    private void showPickRingtoneActivity(Uri ringtoneUri) {
        Intent intent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_RINGTONE);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true);

        if (ringtoneUri == null) {
            ringtoneUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        }

        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, ringtoneUri);

        try {
            startActivityForResult(intent, REQUEST_CODE_PICK_RINGTONE);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "벨소리 선택을 위한 화면을 찾을 수 없습니다.", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * 벨소리, 사진 선택 등의 경우에 선택 결과에 대한 응답 처리
     *
     */
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case REQUEST_CODE_PICK_RINGTONE:
                if (data != null) {
                    String contactId = curContact.id;
                    Uri localUri = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_URI, contactId);

                    final Uri pickedUri = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
                    handleRingtonePicked(contactId, localUri, pickedUri);
                }

                break;

            default:
                break;

        }
    }


    /**
     * 선택된 벨소리 설정
     */
    private void handleRingtonePicked(String contactId, Uri localUri, Uri pickedUri) {
        String curRingtone = null;
        if (pickedUri != null && !RingtoneManager.isDefault(pickedUri)) {
            curRingtone = pickedUri.toString();
        }

        ContentValues localContentValues = new ContentValues();

        localContentValues.put(ContactsContract.Data.RAW_CONTACT_ID, contactId);
        localContentValues.put(ContactsContract.Data.CUSTOM_RINGTONE, curRingtone);
        getContentResolver().update(localUri, localContentValues, null, null);

        Toast.makeText(this, "Ringtone [" + pickedUri + "] assigned to: " + localUri, Toast.LENGTH_LONG);


        // 전화번호부 데이터를 새로 로딩
        reloadContactList();

    }


    /**
     * 전화번호부 데이터를 새로 로딩
     */
    private void reloadContactList() {
        contactList = new ContactFetcher(this).fetchAll();
        contactAdapter.setItems(contactList);
        contactAdapter.notifyDataSetChanged();
    }


}
