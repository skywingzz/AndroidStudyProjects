package org.androidtown.mycontacts;

/**
 * 이메일 정보를 담기 위한 클래스 정의
 */
public class ContactEmail {
	public String address;
	public String type;

	public ContactEmail(String address, String type) {
		this.address = address;
		this.type = type;
	}
}
