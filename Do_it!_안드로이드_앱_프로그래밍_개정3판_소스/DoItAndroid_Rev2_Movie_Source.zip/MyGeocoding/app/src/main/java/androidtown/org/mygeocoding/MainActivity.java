package androidtown.org.mygeocoding;

import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.List;
import java.util.Locale;


public class MainActivity extends AppCompatActivity {
    EditText editText;
    TextView textView;

    Geocoder coder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = (EditText) findViewById(R.id.editText);
        textView = (TextView) findViewById(R.id.textView);

        coder = new Geocoder(this, Locale.KOREAN);
    }

    public void onButton1Clicked(View v) {
        String address = editText.getText().toString();

        try {
            List<Address> addressList = coder.getFromLocationName(address, 3);
            if (addressList != null) {
                for (int i = 0; i < addressList.size(); i++) {
                    Address curAddress = addressList.get(i);
                    StringBuffer buffer = new StringBuffer();
                    for (int k = 0; k <= curAddress.getMaxAddressLineIndex(); k++) {
                        buffer.append(curAddress.getAddressLine(k));
                    }

                    buffer.append("\n\tlatitude : " + curAddress.getLatitude());
                    buffer.append("\n\tlongitude : " + curAddress.getLongitude());

                    textView.append("\nAddress #" + i + " : " + buffer.toString());
                }
            }

        } catch(Exception ex) {
            ex.printStackTrace();
        }


    }

}
