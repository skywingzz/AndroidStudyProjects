package androidtown.org.mysensor;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import java.util.List;


public class MainActivity extends AppCompatActivity {
    TextView textView;
    SensorManager manager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView) findViewById(R.id.textView);

        manager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

    }


    public void onButton1Clicked(View v) {
        List<Sensor> sensorList = manager.getSensorList(Sensor.TYPE_ALL);

        for (int i = 0; i < sensorList.size(); i++) {
            Sensor curSensor = sensorList.get(i);
            String curName = curSensor.getName();

            println("Sensor #" + i + " : " + curName);
        }

        MySensorListener listener = new MySensorListener();
        manager.registerListener(listener, sensorList.get(3), SensorManager.SENSOR_DELAY_UI);
    }

    class MySensorListener implements SensorEventListener {
        @Override
        public void onSensorChanged(SensorEvent event) {
            long timestamp = event.timestamp;

            println("value : " + timestamp + " : " + event.values[0]);
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
    }


    private void println(String data) {
        textView.append(data + "\n");
    }

}
