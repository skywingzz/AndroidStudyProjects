package org.androidtown.threadanimation;

import android.content.Context;
import android.os.Handler;
import android.util.AttributeSet;
import android.widget.ImageView;

/**
 * Created by user on 2015-03-12.
 */
public class ThreadAnimationView extends ImageView {
    int[] imageArray = {R.drawable.emoticon1, R.drawable.emoticon2, R.drawable.emoticon3, R.drawable.emoticon4};

    Handler handler = new Handler();

    public ThreadAnimationView(Context context) {
        super(context);

        init(context);
    }

    public ThreadAnimationView(Context context, AttributeSet attrs) {
        super(context, attrs);

        init(context);
    }

    private void init(Context context) {
        ImageThread thread = new ImageThread();
        thread.start();

    }

    class ImageThread extends Thread {
        boolean running = false;
        int index = 0;
        int interval = 800;

        public void run() {
            running = true;

            while(running) {

                handler.post(new Runnable() {
                    public void run() {

                        setImageResource(imageArray[index]);
                        invalidate();

                    }
                });

                try {
                    Thread.sleep(interval);
                } catch(Exception e) {
                    e.printStackTrace();
                }

                index++;
                if (index > 3) {
                    index = 0;
                }
            }
        }
    }

}
