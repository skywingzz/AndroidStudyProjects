package androidtown.org.myfragmentviewer;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by user on 2015-04-07.
 */
public class FragmentViewer extends Fragment {
    TextView textView;
    ImageView imageView;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_viewer, container, false);

        textView = (TextView) rootView.findViewById(R.id.textView);
        imageView = (ImageView) rootView.findViewById(R.id.imageView);

        return rootView;
    }

    public void updateImage(int index, int resId) {
        textView.setText("���õ� �̹��� : #" + index);
        imageView.setImageResource(resId);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }


}
